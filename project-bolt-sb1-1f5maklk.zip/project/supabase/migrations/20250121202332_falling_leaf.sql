/*
  # Create members table for Raccoons Türkiye

  1. New Tables
    - `members`
      - `id` (bigint, primary key)
      - `twitter_handle` (text, unique)
      - `created_at` (timestamp with time zone)

  2. Security
    - Enable RLS on `members` table
    - Add policies for public read access and authenticated insert
*/

CREATE TABLE IF NOT EXISTS members (
  id bigint PRIMARY KEY GENERATED ALWAYS AS IDENTITY,
  twitter_handle text UNIQUE NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE members ENABLE ROW LEVEL SECURITY;

-- Allow public read access
CREATE POLICY "Allow public read access"
  ON members
  FOR SELECT
  TO public
  USING (true);

-- Allow authenticated users to insert
CREATE POLICY "Allow authenticated insert"
  ON members
  FOR INSERT
  TO authenticated
  WITH CHECK (true);