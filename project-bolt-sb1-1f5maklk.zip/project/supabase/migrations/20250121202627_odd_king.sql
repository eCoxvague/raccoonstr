/*
  # Update RLS policies for members table
  
  1. Changes
    - Allow public inserts into members table
    - Maintain existing read access
  
  2. Security
    - Enable public insert access while maintaining data integrity
    - Keep existing public read access
*/

-- Drop the existing authenticated-only insert policy
DROP POLICY IF EXISTS "Allow authenticated insert" ON members;

-- Create new public insert policy
CREATE POLICY "Allow public insert"
  ON members
  FOR INSERT
  TO public
  WITH CHECK (true);